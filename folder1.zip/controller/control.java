package folder1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

import folder1.model.Oriole;
import folder1.model.Users;
import folder1.service.DataService;
//import folder1.model.Person;
import folder1.service.Oriole_servDAO;
//import folder1.service.PersonService;


@Controller

public class control {

	@Autowired
	Oriole_servDAO gos;
	
	/*@Autowired
	PersonService personService;*/
	
	@RequestMapping("/sonu")
	public ModelAndView toJsp()
	{
		return new ModelAndView("form1");
	}
	
	@RequestMapping("/index")
	public ModelAndView toJsp2()
	{
		return new ModelAndView("form2");
	}
	@RequestMapping("/g1")
	public ModelAndView toJsp3()
	{
		return new ModelAndView("g1");
	}
	@RequestMapping("/s1")
	public ModelAndView toJsp4()
	{
		return new ModelAndView("s1");
	}
	@RequestMapping("/d1")
	public ModelAndView toJsp5()
	{
		return new ModelAndView("d1");
	}
	@RequestMapping("/a1")
	public ModelAndView toJsp1()
	{
		return new ModelAndView("a1");
	}
	@RequestMapping("/br")
	public ModelAndView toJsp6()
	{
		return new ModelAndView("br");
	}
	@RequestMapping("/er")
	public ModelAndView toJsp7()
	{
		return new ModelAndView("er");
	}
	@RequestMapping("/allj")
	public ModelAndView toJsp8()
	{
		return new ModelAndView("allj");
	}
	/*
	
	@RequestMapping("/update")
	public ModelAndView updateMap()
	{
		
		Oriole s= gos.getTypebyId("1");
		System.out.println(s);
		ModelAndView mv=new ModelAndView("form3");
		mv.addObject("hello");
		return mv;
	}
	
	*/
	@RequestMapping("/sonu1")
	public ModelAndView toInsert()
	{
	  Oriole O1 = new Oriole();
	  O1.setTypeid("1");
	  O1.setTypename("Gold_Ring");
	  O1.setDesc("Gold ring_studded with diamond");
	  O1.setPrice("10000");
	  gos.addType(O1);
	 return new ModelAndView("form2");
	  
	}
	
	@RequestMapping("/json")
	public ModelAndView myMap1()
	{
	  //int all=Integer.parseInt(name);
		ModelAndView mv=new ModelAndView("Oriole_type");
		mv.addObject("hello","hello");
		return mv;
	}

	List<Oriole> one=new ArrayList<Oriole>();
	Gson g=new Gson();
	@RequestMapping("/Oriole")
	public @ResponseBody String getValues()
	{
		
			List<Oriole> hol=gos.listOriole();
			//one.add(holder);
			String toreturn=g.toJson(hol);
			
		return toreturn;
	}
	
	
	
		@Autowired  
	 DataService dataService;  
	  
	 @RequestMapping("/form")  
	 public ModelAndView getForm(@ModelAttribute Users u1) {  
	  return new ModelAndView("form","u1",new Users());  
	 }  
	 
	 	 
	 @RequestMapping(value="/register", method=RequestMethod.POST)  
	 public ModelAndView registerUser(@ModelAttribute("u1") Users u1) {  
	  dataService.insertRow(u1);  
	  return new ModelAndView("redirect:list");  
	 }  
	  
	 /* @RequestMapping("/list")  
	 public ModelAndView getList() {  
	  List<Users> Userlist = dataService.getList();  
	  return new ModelAndView("Users", "Userlist", Userlist);  
	 } */ 
	  
	 @RequestMapping("/delete")  
	 public ModelAndView deleteUser(@RequestParam int id) {  
	  dataService.deleteRow(id);  
	  return new ModelAndView("redirect:list");  
	 }  
	  
	 @RequestMapping("/edit")  
	 public ModelAndView editUser(@RequestParam int id,  
	   @ModelAttribute Users u1) {  
	  Users UserObject = dataService.getRowById(id);  
	  return new ModelAndView("edit", "UserObject", UserObject);  
	 }  
	  
	 @RequestMapping("/update")  
	 public ModelAndView updateUser(@ModelAttribute Users u1) {  
	  dataService.updateRow(u1);  
	  return new ModelAndView("redirect:list");  
	 }  
	 
	  
	 @RequestMapping("/list")
		public ModelAndView myMap2()
		{
		  //int all=Integer.parseInt(name);
			ModelAndView mv=new ModelAndView("Users");
			mv.addObject("hello","hello");
			return mv;
		}

		Gson g1=new Gson();
		@RequestMapping("/Users")
		public @ResponseBody String getValue()
		{
			
				List<Users> hold=dataService.getList();
				//one.add(holder);
				String toreturn=g1.toJson(hold);
				
			return toreturn;
		}

	
	 /*
		 * *
		 	 @Qualifier(value="personService")
		 
		public void setPersonService(PersonService ps){
			this.personService = ps;
		}
		
		
		@RequestMapping(value = "/persons", method = RequestMethod.GET)
		public String listPersons(Model model) {
			model.addAttribute("person", new Person());
			model.addAttribute("listPersons", this.personService.listPersons());
			return "person";
		}

		
		//For add and update person both
		@RequestMapping(value= "/person/add", method = RequestMethod.POST)
		public String addPerson(@ModelAttribute("person") Person p){
			
			if(p.getId() == 0){
				//new person, add it
				this.personService.addPerson(p);
			}else{
				//existing person, call update
				this.personService.updatePerson(p);
			}
			
			return "redirect:/persons";
			
		}
		
		@RequestMapping("/remove/{id}")
	    public String removePerson(@PathVariable("id") int id){
			
	        this.personService.removePerson(id);
	        return "redirect:/persons";
	    }
	 
	    @RequestMapping("/edit/{id}")
	    public String editPerson(@PathVariable("id") int id, Model model){
	        model.addAttribute("person", this.personService.getPersonById(id));
	        model.addAttribute("listPersons", this.personService.listPersons());
	        return "person";
	    }
		 */


	  
	
	}

