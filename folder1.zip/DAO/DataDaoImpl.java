package folder1.DAO;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import folder1.model.Users;

@Repository("dataDao")
@Transactional
public class DataDaoImpl implements DataDao {

	
	 @Autowired  
	 SessionFactory sessionFactory;  
	  
	 @Transactional  
	 public int insertRow(Users u1) {  
	  Session session = sessionFactory.openSession();  
	  Transaction tx = session.beginTransaction();  
	  session.saveOrUpdate(u1);  
	  tx.commit();  
	  Serializable id = session.getIdentifier(u1);  
	  session.close();  
	  return (Integer) id;  
	 }  
	  
	 @Transactional
	 public List<Users> getList() {  
	  Session session = sessionFactory.openSession();  
	  @SuppressWarnings("unchecked")  
	  List<Users> userList = session.createQuery("from Users")  
	    .list();  
	  session.close();  
	  return userList;  
	 }  
	  
	 @Transactional  
	 public Users getRowById(int id) {  
	  Session session = sessionFactory.openSession();  
	  Users u1 = (Users) session.load(Users.class, id);  
	  return u1;  
	 }  
	  
	 @Transactional  
	 public int updateRow(Users u1) {  
	  Session session = sessionFactory.openSession();  
	  Transaction tx = session.beginTransaction();  
	  session.saveOrUpdate(u1);  
	  tx.commit();  
	  Serializable id = session.getIdentifier(u1);  
	  session.close();  
	  return (Integer) id;  
	 }  
	  
	 @Transactional  
	 public int deleteRow(int id) {  
	  Session session = sessionFactory.openSession();  
	  Transaction tx = session.beginTransaction();  
	  Users u1 = (Users) session.load(Users.class, id);  
	  session.delete(u1);  
	  tx.commit();  
	  Serializable ids = session.getIdentifier(u1);  
	  session.close();  
	  return (Integer) ids;  
	 } 
	  
	}  
