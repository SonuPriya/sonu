package folder1.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import folder1.model.Oriole;


@Repository("go1")
@Transactional

public class Oriole_DAOImp implements Oriole_DAO{

	private List<Oriole> listType;
			@Autowired
		SessionFactory sessionFactory;
			@SuppressWarnings("unchecked")   
	public List<Oriole> getType() {
			     		
			Session sess=sessionFactory.openSession();
			
			listType=sess.createQuery("from Oriole").list();
			return listType;
		}
			
			
			
		
	public void addType(Oriole o) {
			Session sess=sessionFactory.openSession();
			Transaction tx=sess.beginTransaction();
			sess.save(o);
			tx.commit();
			sess.close();
			System.out.println("success value is "+o.getDesc());
				
	}

	public void updateType(Oriole o) {
			System.out.println("DAO Implementation");
			Session sess=sessionFactory.openSession();
			Transaction trx=sess.beginTransaction();
			sess.saveOrUpdate(o);
			trx.commit();
			sess.close();
		}


	@SuppressWarnings("unchecked")
	public Oriole getTypebyId(String oid) {
		 	Session sess=sessionFactory.openSession();
			Transaction tx=sess.beginTransaction();
			listType= sess.createQuery("from Oriole o where o.typeid=:oid").setParameter("oid", oid).list();
			tx.commit();
			sess.close();
			return listType.size()>0?listType.get(0):null;
			
	}
	
	
	public void removeType(String oid) {
			Session sess=sessionFactory.openSession();
			Transaction trx=sess.beginTransaction();
			
			Oriole o=(Oriole)sess.load(Oriole.class,oid );
			sess.delete(o);
			trx.commit();
			sess.close();
		}

	}





		

	
	
	
