package folder1.DAO;
	
	import java.util.List;

	import folder1.model.Oriole;

	public interface Oriole_DAO {
		
		
		public void addType(Oriole o);
		public void updateType(Oriole o);
		public void removeType(String oid);
		public List<Oriole> getType();
		public Oriole getTypebyId(String oid);

	}

		

