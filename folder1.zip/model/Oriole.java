package folder1.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Oriole {

	@Id
	private String typeid;
	private String typename;   
	private String desc;
	private String price;
	private String Image_add;
	public String getTypeid() {
		return typeid;
	}  
	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}
	
	public String getTypename() {
		return typename;
	}
	
	public void setTypename(String typename) {
		this.typename = typename;
	}

	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getImage_add() {
		return Image_add;
	}
	public void setImage_add(String image_add) {
		Image_add = image_add;
	}
	
		
	}
	


	


