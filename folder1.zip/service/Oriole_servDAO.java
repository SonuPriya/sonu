package folder1.service;

import java.util.List;
import folder1.model.Oriole;

public interface Oriole_servDAO {
	
	public void addType(Oriole o);
	public void updateType(Oriole o);
	public void removeType(String oid);
	public List<Oriole> listOriole();
	public Oriole getTypebyId(String oid);

	}

