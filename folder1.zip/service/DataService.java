package folder1.service;

import java.util.List;

import folder1.model.Users;

public interface DataService {
	 public int insertRow(Users u1);  
	  
	 public List<Users> getList();  
	  
	 public Users getRowById(int id);  
	  
	 public int updateRow(Users u1);  
	  
	 public int deleteRow(int id);  


}
