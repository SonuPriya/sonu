package folder1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import folder1.DAO.DataDao;
import folder1.model.Users;

@Service
@Repository("dataService")
public class DataServiceImpl implements DataService{

	@Autowired  
	 DataDao dataDao;  
	  
	 public int insertRow(Users u1) {  
	  return dataDao.insertRow(u1);  
	 }  
	  
	 public List<Users> getList() {  
	  return dataDao.getList();  
	 }  
	  
	   
	 public Users getRowById(int id) {  
	  return dataDao.getRowById(id);  
	 }  
	  
	  
	 public int updateRow(Users u1) {  
	  return dataDao.updateRow(u1);  
	 }  
	  
	   
	 public int deleteRow(int id) {  
	  return dataDao.deleteRow(id);  
	 }  
}
