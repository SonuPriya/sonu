package folder1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import folder1.DAO.Oriole_DAO;
import folder1.model.Oriole;

	@Service
@Repository("gos1")
	public class Oriole_servDAOImp implements Oriole_servDAO{

	@Autowired
		 Oriole_DAO go1;
	       
	@Transactional
		public void addType(Oriole o) {
			go1.addType(o);
			} 
	@Transactional
		public void updateType(Oriole o) {
			go1.updateType(o);
			}
	@Transactional
		public List<Oriole> listOriole() {
					return go1.getType();
		}
			
	@Transactional
		public Oriole getTypebyId(String oid) {
					return go1.getTypebyId(oid);
		}
	@Transactional
	public void removeType(String oid) {
		go1.removeType(oid);

		
	}


	}

	
	

